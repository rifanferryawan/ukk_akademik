-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Waktu pembuatan: 19. Januari 2014 jam 21:36
-- Versi Server: 5.0.51
-- Versi PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `ukk_akademik`
-- 

-- --------------------------------------------------------

-- 
-- Struktur dari tabel `bidang_studi`
-- 

CREATE TABLE `bidang_studi` (
  `bidang_kode` char(10) NOT NULL,
  `bidang_nama` varchar(30) NOT NULL,
  PRIMARY KEY  (`bidang_kode`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data untuk tabel `bidang_studi`
-- 

INSERT INTO `bidang_studi` VALUES ('KS01', 'Teknik Informatika');
INSERT INTO `bidang_studi` VALUES ('KS02', 'Teknik Mesin');
INSERT INTO `bidang_studi` VALUES ('KS03', 'Teknik Elektro');
INSERT INTO `bidang_studi` VALUES ('KS04', 'Teknik Sipil');
INSERT INTO `bidang_studi` VALUES ('KS05', 'Teknik Arsitektur');
INSERT INTO `bidang_studi` VALUES ('KS06', 'Manajemen Informatika');
INSERT INTO `bidang_studi` VALUES ('KS07', 'Muamalah');
INSERT INTO `bidang_studi` VALUES ('KS08', 'Manajemen Ekonomi');
INSERT INTO `bidang_studi` VALUES ('KS09', 'Kebidanan');
INSERT INTO `bidang_studi` VALUES ('KS10', 'Kebidanan');
INSERT INTO `bidang_studi` VALUES ('KS11', 'Tarbiyah');
INSERT INTO `bidang_studi` VALUES ('KS12', 'Fisika');

-- --------------------------------------------------------

-- 
-- Struktur dari tabel `guru`
-- 

CREATE TABLE `guru` (
  `guru_kode` char(10) NOT NULL,
  `kompetensi_kode` char(10) NOT NULL,
  `guru_NIP` char(16) NOT NULL,
  `guru_nama` varchar(25) NOT NULL,
  `guru_alamat` varchar(25) NOT NULL,
  `guru_telpon` varchar(15) NOT NULL,
  PRIMARY KEY  (`guru_kode`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data untuk tabel `guru`
-- 

INSERT INTO `guru` VALUES ('gr01', 'KK01', '123450001', 'Ahmad', 'selomerto', '888888888');
INSERT INTO `guru` VALUES ('gr02', 'KK-3', '123450002', 'Sunar', 'wonosobo', '888888887');
INSERT INTO `guru` VALUES ('GR03', 'KK01', '123450004', 'Bahrudin', 'Magelang', '98965468');

-- --------------------------------------------------------

-- 
-- Struktur dari tabel `kompetensi_keahlian`
-- 

CREATE TABLE `kompetensi_keahlian` (
  `kompetensi_kode` char(10) NOT NULL,
  `bidang_kode` char(10) NOT NULL,
  `kompetensi_nama` varchar(25) NOT NULL,
  PRIMARY KEY  (`kompetensi_kode`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data untuk tabel `kompetensi_keahlian`
-- 

INSERT INTO `kompetensi_keahlian` VALUES ('KK01', 'KS02', 'Desktop');
INSERT INTO `kompetensi_keahlian` VALUES ('KK-3', 'KS08', 'TEst');

-- --------------------------------------------------------

-- 
-- Struktur dari tabel `nilai`
-- 

CREATE TABLE `nilai` (
  `siswa_NISN` char(10) NOT NULL,
  `guru_kode` char(10) NOT NULL,
  `sk_kode` char(10) NOT NULL,
  `nilai_angka` float NOT NULL,
  `nilai_huruf` varchar(2) NOT NULL,
  PRIMARY KEY  (`siswa_NISN`,`guru_kode`,`sk_kode`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data untuk tabel `nilai`
-- 


-- --------------------------------------------------------

-- 
-- Struktur dari tabel `pengguna`
-- 

CREATE TABLE `pengguna` (
  `id` int(11) NOT NULL auto_increment,
  `nama` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `level` varchar(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- 
-- Dumping data untuk tabel `pengguna`
-- 

INSERT INTO `pengguna` VALUES (1, 'Rifan Ferryawan', 'fanggo@facebook.com', 'fanggo', 'fanggo', 'admin');
INSERT INTO `pengguna` VALUES (2, 'fanggofan', 'fanggo@facebook.com', 'rifan', 'rifan', 'user');

-- --------------------------------------------------------

-- 
-- Struktur dari tabel `siswa`
-- 

CREATE TABLE `siswa` (
  `siswa_NISN` char(10) NOT NULL,
  `kompetensi_kode` char(10) NOT NULL,
  `siswa_nama` varchar(30) NOT NULL,
  `siswa_alamat` varchar(50) NOT NULL,
  `siswa_tgl_lahir` date NOT NULL,
  `siswa_foto` longblob NOT NULL,
  PRIMARY KEY  (`siswa_NISN`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data untuk tabel `siswa`
-- 

INSERT INTO `siswa` VALUES ('7997', 'KK01', 'Dani', 'Wonosobo', '2000-01-01', 0x6162636465);

-- --------------------------------------------------------

-- 
-- Struktur dari tabel `standar_kompetensi`
-- 

CREATE TABLE `standar_kompetensi` (
  `sk_kode` char(10) NOT NULL,
  `kompetensi_kode` char(10) NOT NULL,
  `sk_nama` varchar(60) NOT NULL,
  `sk_kelas` text NOT NULL,
  PRIMARY KEY  (`sk_kode`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data untuk tabel `standar_kompetensi`
-- 

INSERT INTO `standar_kompetensi` VALUES ('SK001', 'KK01', 'Perakitan Komputer 1', 'X');
INSERT INTO `standar_kompetensi` VALUES ('SK002', 'KK-3', 'Sistem Digital', 'X');

-- --------------------------------------------------------

-- 
-- Struktur dari tabel `wali_murid`
-- 

CREATE TABLE `wali_murid` (
  `wali_id` char(10) NOT NULL,
  `siswa_NISN` char(10) NOT NULL,
  `wali_nama_ayah` varchar(25) NOT NULL,
  `wali_pekerjaan_ayah` varchar(15) NOT NULL,
  `wali_nama_ibu` varchar(25) NOT NULL,
  `wali_pekerjaan_ibu` varchar(15) NOT NULL,
  `wali_alamat` varchar(50) NOT NULL,
  `wali_telpon` varchar(15) NOT NULL,
  PRIMARY KEY  (`wali_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data untuk tabel `wali_murid`
-- 

INSERT INTO `wali_murid` VALUES ('1', '7997', 'A', 'aa', 'B', 'bb', 'WSB', '0676');
